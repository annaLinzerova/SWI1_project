CREATE TABLE dlc
(
 id_dlc   INTEGER NOT NULL,
 name_dlc VARCHAR2(50),
 cost_dlc INTEGER
)
;

ALTER TABLE dlc
 ADD CONSTRAINT dlc_PK PRIMARY KEY ( id_dlc )
;

CREATE TABLE "character"
(
 id_character       INTEGER NOT NULL,
 name_character     VARCHAR2(100),
 cost_character     INTEGER,
 owned_character    CHAR(1),
 killer_or_survivor VARCHAR2(10),
 story              VARCHAR2(1000),
 dlc_id_dlc         INTEGER NOT NULL
)
;

ALTER TABLE "character"
 ADD CONSTRAINT character_PK PRIMARY KEY ( id_character )
;

CREATE TABLE mdcl_nplayer
(
 dlc_id_dlc       INTEGER NOT NULL,
 player_id_player INTEGER NOT NULL
)
;

ALTER TABLE mdcl_nplayer
 ADD CONSTRAINT Relation_3_PK PRIMARY KEY ( dlc_id_dlc, player_id_player )
;

CREATE TABLE mplayer_ncharacter
(
 player_id_player       INTEGER NOT NULL,
 character_id_character INTEGER NOT NULL
)
;

ALTER TABLE mplayer_ncharacter
 ADD CONSTRAINT Relation_4_PK PRIMARY KEY ( player_id_player, character_id_character )
;

CREATE TABLE mplayer_nskin
(
 player_id_player INTEGER NOT NULL,
 skin_id_skin     INTEGER NOT NULL
)
;

ALTER TABLE mplayer_nskin
 ADD CONSTRAINT Relation_5_PK PRIMARY KEY ( player_id_player, skin_id_skin )
;

CREATE TABLE player
(
 id_player INTEGER NOT NULL,
 username  VARCHAR2(35),
 email     VARCHAR2(50),
 currency  INTEGER
)
;

ALTER TABLE player
 ADD CONSTRAINT player_PK PRIMARY KEY ( id_player )
;

CREATE TABLE skin
(
 id_skin                INTEGER NOT NULL,
 value_skin             VARCHAR2(20),
 cost_skin              INTEGER,
 owned_skin             CHAR(1),
 character_id_character INTEGER NOT NULL
)
;

ALTER TABLE skin
 ADD CONSTRAINT skin_PK PRIMARY KEY ( id_skin )
;

ALTER TABLE "character"
 ADD CONSTRAINT character_dlc_FK FOREIGN KEY
 (
  dlc_id_dlc
 )
 REFERENCES dlc
 (
  id_dlc
 )
;

ALTER TABLE mdcl_nplayer
 ADD CONSTRAINT Relation_3_dlc_FK FOREIGN KEY
 (
  dlc_id_dlc
 )
 REFERENCES dlc
 (
  id_dlc
 )
;

ALTER TABLE mdcl_nplayer
 ADD CONSTRAINT Relation_3_player_FK FOREIGN KEY
 (
  player_id_player
 )
 REFERENCES player
 (
  id_player
 )
;

ALTER TABLE mplayer_ncharacter
 ADD CONSTRAINT Relation_4_character_FK FOREIGN KEY
 (
  character_id_character
 )
 REFERENCES "character"
 (
  id_character
 )
;

ALTER TABLE mplayer_ncharacter
 ADD CONSTRAINT Relation_4_player_FK FOREIGN KEY
 (
  player_id_player
 )
 REFERENCES player
 (
  id_player
 )
;

ALTER TABLE mplayer_nskin
 ADD CONSTRAINT Relation_5_player_FK FOREIGN KEY
 (
  player_id_player
 )
 REFERENCES player
 (
  id_player
 )
;

ALTER TABLE mplayer_nskin
 ADD CONSTRAINT Relation_5_skin_FK FOREIGN KEY
 (
  skin_id_skin
 )
 REFERENCES skin
 (
  id_skin
 )
;

ALTER TABLE skin
 ADD CONSTRAINT skin_character_FK FOREIGN KEY
 (
  character_id_character
 )
 REFERENCES "character"
 (
  id_character
 )
;
