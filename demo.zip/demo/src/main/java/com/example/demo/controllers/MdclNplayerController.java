package com.example.demo.controllers;

import entities.MdclNplayer;
import entities.MdclNplayerId;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import repositories.MdclNplayerRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/mdcl-nplayer")
public class MdclNplayerController {

    private final MdclNplayerRepository mdclNplayerRepository;

    public MdclNplayerController(MdclNplayerRepository mdclNplayerRepository) {
        this.mdclNplayerRepository = mdclNplayerRepository;
    }

    @GetMapping
    public List<MdclNplayer> getAll() {
        return mdclNplayerRepository.findAll();
    }

    @GetMapping("/by-id")
    public ResponseEntity<MdclNplayer> getById(@RequestParam Integer dlcIdDlc, @RequestParam Integer playerIdPlayer) {
        MdclNplayerId id = new MdclNplayerId(dlcIdDlc, playerIdPlayer);
        Optional<MdclNplayer> item = mdclNplayerRepository.findById(id);
        return item.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public MdclNplayer create(@RequestBody MdclNplayer item) {
        return mdclNplayerRepository.save(item);
    }

    @DeleteMapping
    public ResponseEntity<Void> delete(@RequestParam Integer dlcIdDlc, @RequestParam Integer playerIdPlayer) {
        MdclNplayerId id = new MdclNplayerId(dlcIdDlc, playerIdPlayer);
        if (!mdclNplayerRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        mdclNplayerRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
