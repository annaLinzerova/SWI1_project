package com.example.demo.controllers;

import entities.Dlc;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import repositories.DlcRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/dlcs")
public class DlcController {

    private final DlcRepository dlcRepository;

    public DlcController(DlcRepository dlcRepository) {
        this.dlcRepository = dlcRepository;
    }

    @GetMapping
    public List<Dlc> getAll() {
        return dlcRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Dlc> getById(@PathVariable Integer id) {
        Optional<Dlc> dlc = dlcRepository.findById(id);
        return dlc.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Dlc create(@RequestBody Dlc dlc) {
        return dlcRepository.save(dlc);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Dlc> update(@PathVariable Integer id, @RequestBody Dlc dlc) {
        if (!dlcRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        dlc.setIdDlc(id);
        return ResponseEntity.ok(dlcRepository.save(dlc));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        if (!dlcRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        dlcRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
