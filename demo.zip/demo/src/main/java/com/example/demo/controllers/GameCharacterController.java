package com.example.demo.controllers;

import entities.GameCharacter;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import repositories.GameCharacterRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/characters")
public class GameCharacterController {

    private final GameCharacterRepository gameCharacterRepository;

    public GameCharacterController(GameCharacterRepository gameCharacterRepository) {
        this.gameCharacterRepository = gameCharacterRepository;
    }

    @GetMapping
    public List<GameCharacter> getAll() {
        return gameCharacterRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<GameCharacter> getById(@PathVariable Integer id) {
        Optional<GameCharacter> character = gameCharacterRepository.findById(id);
        return character.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public GameCharacter create(@RequestBody GameCharacter character) {
        return gameCharacterRepository.save(character);
    }

    @PutMapping("/{id}")
    public ResponseEntity<GameCharacter> update(@PathVariable Integer id, @RequestBody GameCharacter character) {
        if (!gameCharacterRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        character.setIdCharacter(id);
        return ResponseEntity.ok(gameCharacterRepository.save(character));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        if (!gameCharacterRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        gameCharacterRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
