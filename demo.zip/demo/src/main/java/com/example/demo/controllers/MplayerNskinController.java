package com.example.demo.controllers;

import entities.MplayerNskin;
import entities.MplayerNskinId;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import repositories.MplayerNskinRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/mplayer-nskin")
public class MplayerNskinController {

    private final MplayerNskinRepository mplayerNskinRepository;

    public MplayerNskinController(MplayerNskinRepository mplayerNskinRepository) {
        this.mplayerNskinRepository = mplayerNskinRepository;
    }

    @GetMapping
    public List<MplayerNskin> getAll() {
        return mplayerNskinRepository.findAll();
    }

    @GetMapping("/by-id")
    public ResponseEntity<MplayerNskin> getById(@RequestParam Integer skinIdSkin, @RequestParam Integer playerIdPlayer) {
        MplayerNskinId id = new MplayerNskinId(playerIdPlayer, skinIdSkin);
        Optional<MplayerNskin> item = mplayerNskinRepository.findById(id);
        return item.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public MplayerNskin create(@RequestBody MplayerNskin item) {
        return mplayerNskinRepository.save(item);
    }

    @DeleteMapping
    public ResponseEntity<Void> delete(@RequestParam Integer skinIdSkin, @RequestParam Integer playerIdPlayer) {
        MplayerNskinId id = new MplayerNskinId(playerIdPlayer, skinIdSkin);
        if (!mplayerNskinRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        mplayerNskinRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
