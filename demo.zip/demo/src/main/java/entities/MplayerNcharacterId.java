package entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class MplayerNcharacterId implements Serializable {

    @Column(name = "player_id_player")
    private Integer playerIdPlayer;

    @Column(name = "character_id_character")
    private Integer characterIdCharacter;

    public MplayerNcharacterId() {
    }

    public MplayerNcharacterId(Integer playerIdPlayer, Integer characterIdCharacter) {
        this.playerIdPlayer = playerIdPlayer;
        this.characterIdCharacter = characterIdCharacter;
    }

    public Integer getPlayerIdPlayer() {
        return playerIdPlayer;
    }

    public void setPlayerIdPlayer(Integer playerIdPlayer) {
        this.playerIdPlayer = playerIdPlayer;
    }

    public Integer getCharacterIdCharacter() {
        return characterIdCharacter;
    }

    public void setCharacterIdCharacter(Integer characterIdCharacter) {
        this.characterIdCharacter = characterIdCharacter;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MplayerNcharacterId that = (MplayerNcharacterId) o;
        return Objects.equals(playerIdPlayer, that.playerIdPlayer)
                && Objects.equals(characterIdCharacter, that.characterIdCharacter);
    }

    @Override
    public int hashCode() {
        return Objects.hash(playerIdPlayer, characterIdCharacter);
    }
}
