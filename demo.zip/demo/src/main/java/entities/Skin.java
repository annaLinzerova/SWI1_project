package entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "skin")
public class Skin {

    @Id
    @Column(name = "id_skin")
    private Integer idSkin;

    @Column(name = "value_skin", length = 20)
    private String valueSkin;

    @Column(name = "cost_skin")
    private Integer costSkin;

    @Column(name = "owned_skin", length = 1)
    private String ownedSkin;

    @Column(name = "character_id_character", nullable = false)
    private Integer characterIdCharacter;

    public Skin() {
    }

    public Integer getIdSkin() {
        return idSkin;
    }

    public void setIdSkin(Integer idSkin) {
        this.idSkin = idSkin;
    }

    public String getValueSkin() {
        return valueSkin;
    }

    public void setValueSkin(String valueSkin) {
        this.valueSkin = valueSkin;
    }

    public Integer getCostSkin() {
        return costSkin;
    }

    public void setCostSkin(Integer costSkin) {
        this.costSkin = costSkin;
    }

    public Integer getCharacterIdCharacter() {
        return characterIdCharacter;
    }

    public void setCharacterIdCharacter(Integer characterIdCharacter) {
        this.characterIdCharacter = characterIdCharacter;
    }

    public String getOwnedSkin() {
        return ownedSkin;
    }

    public void setOwnedSkin(String ownedSkin) {
        this.ownedSkin = ownedSkin;
    }
}
