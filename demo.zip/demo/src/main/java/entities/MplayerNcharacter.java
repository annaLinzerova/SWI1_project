package entities;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "mplayer_ncharacter")
public class MplayerNcharacter {

    @EmbeddedId
    private MplayerNcharacterId id;

    public MplayerNcharacter() {
    }

    public MplayerNcharacterId getId() {
        return id;
    }

    public void setId(MplayerNcharacterId id) {
        this.id = id;
    }
}
