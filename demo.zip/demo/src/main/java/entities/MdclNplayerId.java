package entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class MdclNplayerId implements Serializable {

    @Column(name = "dlc_id_dlc")
    private Integer dlcIdDlc;

    @Column(name = "player_id_player")
    private Integer playerIdPlayer;

    public MdclNplayerId() {
    }

    public MdclNplayerId(Integer dlcIdDlc, Integer playerIdPlayer) {
        this.dlcIdDlc = dlcIdDlc;
        this.playerIdPlayer = playerIdPlayer;
    }

    public Integer getDlcIdDlc() {
        return dlcIdDlc;
    }

    public void setDlcIdDlc(Integer dlcIdDlc) {
        this.dlcIdDlc = dlcIdDlc;
    }

    public Integer getPlayerIdPlayer() {
        return playerIdPlayer;
    }

    public void setPlayerIdPlayer(Integer playerIdPlayer) {
        this.playerIdPlayer = playerIdPlayer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MdclNplayerId that = (MdclNplayerId) o;
        return Objects.equals(dlcIdDlc, that.dlcIdDlc) && Objects.equals(playerIdPlayer, that.playerIdPlayer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dlcIdDlc, playerIdPlayer);
    }
}
