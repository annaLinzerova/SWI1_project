package entities;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "mplayer_nskin")
public class MplayerNskin {

    @EmbeddedId
    private MplayerNskinId id;

    public MplayerNskin() {
    }

    public MplayerNskinId getId() {
        return id;
    }

    public void setId(MplayerNskinId id) {
        this.id = id;
    }
}
