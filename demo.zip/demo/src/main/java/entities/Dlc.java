package entities;

import jakarta.persistence.*;

@Entity
@Table(name = "dlc")
public class Dlc {

    @Id
    @Column(name = "id_dlc")
    private Integer idDlc;

    @Column(name = "name_dlc", length = 50)
    private String nameDlc;

    @Column(name = "cost_dlc")
    private Integer costDlc;

    public Dlc() {
    }

    public Integer getIdDlc() {
        return idDlc;
    }

    public void setIdDlc(Integer idDlc) {
        this.idDlc = idDlc;
    }

    public String getNameDlc() {
        return nameDlc;
    }

    public void setNameDlc(String nameDlc) {
        this.nameDlc = nameDlc;
    }

    public Integer getCostDlc() {
        return costDlc;
    }

    public void setCostDlc(Integer costDlc) {
        this.costDlc = costDlc;
    }
}
