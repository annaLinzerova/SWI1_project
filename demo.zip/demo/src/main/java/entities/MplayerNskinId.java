package entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class MplayerNskinId implements Serializable {

    @Column(name = "player_id_player")
    private Integer playerIdPlayer;

    @Column(name = "skin_id_skin")
    private Integer skinIdSkin;

    public MplayerNskinId() {
    }

    public MplayerNskinId(Integer playerIdPlayer, Integer skinIdSkin) {
        this.playerIdPlayer = playerIdPlayer;
        this.skinIdSkin = skinIdSkin;
    }

    public Integer getPlayerIdPlayer() {
        return playerIdPlayer;
    }

    public void setPlayerIdPlayer(Integer playerIdPlayer) {
        this.playerIdPlayer = playerIdPlayer;
    }

    public Integer getSkinIdSkin() {
        return skinIdSkin;
    }

    public void setSkinIdSkin(Integer skinIdSkin) {
        this.skinIdSkin = skinIdSkin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MplayerNskinId that = (MplayerNskinId) o;
        return Objects.equals(skinIdSkin, that.skinIdSkin) && Objects.equals(playerIdPlayer, that.playerIdPlayer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(skinIdSkin, playerIdPlayer);
    }
}
