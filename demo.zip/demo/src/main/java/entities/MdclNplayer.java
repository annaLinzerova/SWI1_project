package entities;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "mdcl_nplayer")
public class MdclNplayer {

    @EmbeddedId
    private MdclNplayerId id;

    public MdclNplayer() {
    }

    public MdclNplayerId getId() {
        return id;
    }

    public void setId(MdclNplayerId id) {
        this.id = id;
    }
}
