package entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "\"character\"")
public class GameCharacter {

    @Id
    @Column(name = "id_character")
    private Integer idCharacter;

    @Column(name = "name_character", length = 100)
    private String nameCharacter;

    @Column(name = "cost_character")
    private Integer costCharacter;

    @Column(name = "owned_character", length = 1)
    private String ownedCharacter;

    @Column(name = "killer_or_survivor", length = 10)
    private String killerOrSurvivor;

    @Column(name = "story", length = 1000)
    private String story;

    @Column(name = "dlc_id_dlc", nullable = false)
    private Integer dlcIdDlc;

    public GameCharacter() {
    }

    public Integer getIdCharacter() {
        return idCharacter;
    }

    public void setIdCharacter(Integer idCharacter) {
        this.idCharacter = idCharacter;
    }

    public String getNameCharacter() {
        return nameCharacter;
    }

    public void setNameCharacter(String nameCharacter) {
        this.nameCharacter = nameCharacter;
    }

    public Integer getCostCharacter() {
        return costCharacter;
    }

    public void setCostCharacter(Integer costCharacter) {
        this.costCharacter = costCharacter;
    }

    public String getOwnedCharacter() {
        return ownedCharacter;
    }

    public void setOwnedCharacter(String ownedCharacter) {
        this.ownedCharacter = ownedCharacter;
    }

    public String getKillerOrSurvivor() {
        return killerOrSurvivor;
    }

    public void setKillerOrSurvivor(String killerOrSurvivor) {
        this.killerOrSurvivor = killerOrSurvivor;
    }

    public String getStory() {
        return story;
    }

    public void setStory(String story) {
        this.story = story;
    }

    public Integer getDlcIdDlc() {
        return dlcIdDlc;
    }

    public void setDlcIdDlc(Integer dlcIdDlc) {
        this.dlcIdDlc = dlcIdDlc;
    }
}
