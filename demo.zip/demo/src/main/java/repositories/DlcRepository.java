package repositories;

import entities.Dlc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DlcRepository extends JpaRepository<Dlc, Integer> {
}
