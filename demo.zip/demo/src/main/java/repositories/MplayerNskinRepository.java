package repositories;

import entities.MplayerNskin;
import entities.MplayerNskinId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MplayerNskinRepository extends JpaRepository<MplayerNskin, MplayerNskinId> {
}
